function J = colorfinalresult(seg,img)
if size(img,3)==3
    R = img(:,:,1);G=img(:,:,2);B=img(:,:,3);
    bwedge = edge(seg,'canny');
    ind = find(bwedge(:)==1);
    R(ind) = 255;G(ind)=0;B(ind)=0;
    J(:,:,1) = R;J(:,:,2)=G;J(:,:,3)=B;
else
    R = img;G=img;B=img;
    bwedge = edge(seg,'canny');
    ind = find(bwedge(:)==1);
    R(ind) = 255;G(ind)=0;B(ind)=0;
    J(:,:,1) = R;J(:,:,2)=G;J(:,:,3)=B;
end
end